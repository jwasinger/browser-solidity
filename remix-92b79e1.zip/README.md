# Automatic build
Built website from `92b79e1`. See https://github.com/ethereum/browser-solidity/ for details.
To use an offline copy, download `remix-92b79e1.zip`.
